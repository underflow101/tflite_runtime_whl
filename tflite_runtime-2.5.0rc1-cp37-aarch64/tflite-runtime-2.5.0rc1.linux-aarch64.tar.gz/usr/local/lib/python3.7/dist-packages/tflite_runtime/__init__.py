__version__ = '2.5.0rc1'
__git_version__ = '0.6.0-107626-g0d1805a'
