__version__ = '2.6.0'
__git_version__ = '0.6.0-108269-gd5bef0f'
